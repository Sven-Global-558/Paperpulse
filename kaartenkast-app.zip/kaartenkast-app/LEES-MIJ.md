# De Kaartenkast — zelfstandige versie

In dit mapje zit een complete, op zichzelf staande app:

- `index.html` — de app zelf
- `manifest.json` + `sw.js` — zorgen dat je 'm als app-icoon kunt installeren
- `icon-192.png` / `icon-512.png` — het app-icoon

Alles werkt **lokaal op je eigen toestel**: kaartjes en foto's worden bewaard in de browseropslag van je telefoon/computer (IndexedDB), en blijven daar staan totdat jij ze verwijdert — geen account, geen cloud, geen kosten. Tekstherkenning gebeurt ook lokaal in de browser (via Tesseract.js), dus je hebt er geen internetverbinding voor nodig zodra de pagina eenmaal geladen is.

## Stap 1: hosten (eenmalig, ca. 10 minuten)

De makkelijkste gratis manier is **GitHub Pages**:

1. Ga naar [github.com](https://github.com) en maak een gratis account (als je die nog niet hebt).
2. Maak een nieuwe **public repository**, bijvoorbeeld genaamd `kaartenkast`.
3. Upload alle bestanden uit dit mapje naar die repository (via "Add file" → "Upload files" in de GitHub-website, gewoon slepen kan ook).
4. Ga naar **Settings → Pages** in die repository, en zet bij "Source" de branch op `main` (map `/root`).
5. Na ongeveer een minuut krijg je een link zoals `https://jouwgebruikersnaam.github.io/kaartenkast/` — dat is je app.

**Alternatief**, net zo makkelijk: [Netlify Drop](https://app.netlify.com/drop) — sleep het hele mapje in de browser en je krijgt direct een werkende link.

## Stap 2: installeren op je telefoon

Open de link (uit stap 1) in de browser van je telefoon:

- **iPhone (Safari)**: tik op het Deel-icoon (vierkantje met pijltje omhoog) → "Zet op beginscherm".
- **Android (Chrome)**: tik op het menu (drie puntjes) → "App installeren" of "Toevoegen aan startscherm".

Je krijgt dan een eigen app-icoon met "Kaartenkast" erop, die opent zonder browserbalk — voelt aan als een echte app.

## Testen zonder te hosten

Je kunt `index.html` ook gewoon lokaal openen (dubbelklikken) om te testen. De camera en opslag werken dan meestal ook al, maar "installeren als app" werkt pas betrouwbaar zodra de bestanden ergens via `https://` gehost worden.

## Verschil met de Claude-versie

- ✅ Opslag verdwijnt nooit meer, ook niet als je de app sluit
- ✅ Geen berichten-quotum, geen kosten
- ⚠️ Land wordt alleen automatisch geraden op basis van de landcode van het telefoonnummer (niet uit het volledige adres) — check dat veld dus altijd even
- ⚠️ Bedrijf en naam worden niet automatisch ingevuld; je leest ze af uit de herkende tekst die onder de foto verschijnt en typt ze zelf over (dat gaat na een paar kaartjes heel snel)
